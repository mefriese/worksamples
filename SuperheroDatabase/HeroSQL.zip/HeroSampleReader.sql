USE superhero;


select * from sighting;