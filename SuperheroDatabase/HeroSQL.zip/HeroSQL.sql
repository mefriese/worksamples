DROP DATABASE IF EXISTS superhero;

CREATE DATABASE superhero;

USE superhero;

CREATE TABLE Hero (
   HeroName VARCHAR(20) NOT NULL,
   NameReal VARCHAR(30) NOT NULL,
   Description TEXT NOT NULL,
   MoralAlignment VARCHAR(30),
   PRIMARY KEY (HeroName)
);

CREATE TABLE Civilian(
	CivilianName VARCHAR(30) NOT NULL,
    Description TEXT,
    PRIMARY KEY (CivilianName)
);

CREATE TABLE Location (
	LocationName VARCHAR(30) NOT NULL,
    Address VARCHAR(120) NOT NULL,
    Longitude DOUBLE NOT NULL,
    Latitude DOUBLE NOT NULL,
    Description TEXT NOT NULL,
    PRIMARY KEY (LocationName)
);

CREATE TABLE Organization (
	OrgName VARCHAR(30) NOT NULL,
	MissionStatement TEXT NOT NULL,
    Classification VARCHAR(60),
    Headquarters VARCHAR(30) NOT NULL,
	PRIMARY KEY (OrgName)
);

CREATE TABLE Sighting (
	SightingID INT NOT NULL auto_increment,
    DateOf DATE NOT NULL,
    Description VARCHAR(120) NOT NULL,
    LocationName VARCHAR(30),
    PRIMARY KEY (SightingID)
);

CREATE TABLE Power (
	PowerName VARCHAR(30) NOT NULL,
    Description TEXT NOT NULL,
    PowerRoleType VARCHAR(20),
    CoolnessRating INT,
    UtilityViability INT,
    PRIMARY KEY (PowerName)
);

CREATE TABLE HeroPower (
	HeroName VARCHAR(20) NOT NULL references Hero.HeroName,
    PowerName VARCHAR(30) NOT NULL REFERENCES Power.PowerName,
    PRIMARY KEY(HeroName,PowerName)
);

CREATE TABLE HeroOrganization (
	HeroName VARCHAR(20) NOT NULL,
    OrgName VARCHAR(30) NOT NULL,
    PRIMARY KEY (HeroName, OrgName)
);

CREATE TABLE CivilianOrganization (
	CivilianName VARCHAR(30) NOT NULL,
    OrgName VARCHAR(30) NOT NULL,
    PRIMARY KEY (CivilianName, OrgName)
);

CREATE TABLE HeroSighting (
	HeroName VARCHAR(20) NOT NULL,
    SightingID INT NOT NULL,
    PRIMARY KEY (HeroName, SightingID)
);

CREATE TABLE Bases (
	OrgName VARCHAR(30) NOT NULL,
    BaseType VARCHAR(30) NOT NULL,
    LocationName VARCHAR(30) NOT NULL,
    PRIMARY KEY (OrgName, LocationName)
);