USE superhero;

INSERT INTO Hero (HeroName,NameReal,Description,MoralAlignment)
VALUES ('Sir Bunnington','Jack Rabbit','The Bun-Bun fun time warrior!','Chaotic Good'), ('Meth','Methamphetamine','Not even once....','Chaotic Evil'), ('NocNox','Darren Jay','The poisoner of the night','Chaotic Neutral');

INSERT INTO Civilian (CivilianName)
VALUES ('Jack Kerouac');

INSERT INTO Location (LocationName, Address, Longitude, Latitude, Description)
VALUES ('Space','N/A',0,0,'Literally, in orbit.'), ('Angel Grove Krispy Kreme','9410 Rosedale Hwy',35.386,-119.106,'The Krispy Kreme in Angel Grove that conceals the Zeo Crystal'), ('UN','New York, NY 10017',40.748,-73.967,'Literally the Headquarters for the United Nations');

INSERT INTO Organization (OrgName, MissionStatement,Classification,Headquarters)
VALUES ('United Nations','To Promote International Cooperation','International Negotiating Power','UN'),('Centurion Squad','Cogito, Ergo moro','Adventuring Party (Idiots)','Angel Grove Krispy Kreme');

INSERT INTO Sighting (DateOf,Description,LocationName)
VALUES (now(),'Saw NocNox sipping coffee and glaring at me','Angel Grove Krispy Kreme');

INSERT INTO Power (PowerName, Description, PowerRoleType, CoolnessRating, UtilityViability)
VALUES ('Death Strike','Chance to instantly kill foe if you can sneak up and deliver melee attack','Offensive, Stealth',8,7),('DRUGS','Ruins a life. Feels good doing it.','Sabotage',4,2),('Bunny Hop','Can leap tall buildings in a single bound','Mobility',6,9);

INSERT INTO HeroPower (HeroName, Powername)
VALUES ('Sir Bunnington','Bunny Hop'),('Meth','DRUGS'),('NocNox','Death Strike');

INSERT INTO HeroOrganization (HeroName, OrgName)
VALUES ('Sir Bunnington','United Nations'),('NocNox','Centurion Squad'),('Meth','United Nations'),('NocNox','United Nations');

INSERT INTO CivilianOrganization (CivilianName, OrgName)
VALUES ('Jack Kerouac','United Nations');

INSERT INTO HeroSighting (HeroName, SightingID)
VALUES ('NocNox',1),('Sir Bunnington',1);

INSERT INTO Bases (OrgName, BaseType,LocationName)
VALUES ('United Nations','Space Station','Space');